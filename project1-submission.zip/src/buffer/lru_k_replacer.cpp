//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// lru_k_replacer.cpp
//
// Identification: src/buffer/lru_k_replacer.cpp
//
// Copyright (c) 2015-2022, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "buffer/lru_k_replacer.h"

namespace bustub {

LRUKReplacer::LRUKReplacer(size_t num_frames, size_t k) : replacer_size_(num_frames), k_(k) {
  BUSTUB_ASSERT(k > 0, "k must be positive");
}

auto LRUKReplacer::Evict(frame_id_t *frame_id) -> bool {
  std::scoped_lock<std::mutex> lock(latch_);
  if (curr_size_ == 0) {
    return false;
  }

  frame_id_t victim = -1;
  bool victim_inf = false;  // victim 是否为 +inf 距离
  size_t max_dist = 0;      // 有限距离中的最大值
  size_t earliest = 0;      // +inf 帧中最早的访问时间

  for (const auto &[fid, node] : node_store_) {
    if (!node.is_evictable_) {
      continue;
    }
    if (node.history_.size() < k_) {
      // 距离 +inf：优先淘汰；并列时取最早访问的
      size_t first_ts = node.history_.back();  // 列表尾部 = 最早一次访问
      if (!victim_inf || first_ts < earliest) {
        victim = fid;
        victim_inf = true;
        earliest = first_ts;
      }
    } else if (!victim_inf) {
      size_t dist = current_timestamp_ - node.history_.back();  // 尾部 = 倒数第 k 次
      if (victim == -1 || dist > max_dist) {
        victim = fid;
        max_dist = dist;
      }
    }
  }

  if (victim == -1) {
    return false;
  }
  *frame_id = victim;
  node_store_.erase(victim);  // 清除该帧的访问历史
  curr_size_--;
  return true;
}

void LRUKReplacer::RecordAccess(frame_id_t frame_id) {
  std::scoped_lock<std::mutex> lock(latch_);
  BUSTUB_ASSERT(frame_id >= 0 && static_cast<size_t>(frame_id) < replacer_size_, "invalid frame_id");

  auto &node = node_store_[frame_id];  // 首次访问会默认创建节点
  node.history_.push_front(++current_timestamp_);
  if (node.history_.size() > k_) {
    node.history_.pop_back();  // 只保留最近 k 次
  }
}

void LRUKReplacer::SetEvictable(frame_id_t frame_id, bool set_evictable) {
  std::scoped_lock<std::mutex> lock(latch_);
  BUSTUB_ASSERT(frame_id >= 0 && static_cast<size_t>(frame_id) < replacer_size_, "invalid frame_id");

  auto it = node_store_.find(frame_id);
  if (it == node_store_.end()) {
    return;  // 从未被访问过的帧：不改变任何状态
  }
  bool old = it->second.is_evictable_;
  if (old != set_evictable) {
    if (set_evictable) {
      curr_size_++;
    } else {
      curr_size_--;
    }
    it->second.is_evictable_ = set_evictable;
  }
}

void LRUKReplacer::Remove(frame_id_t frame_id) {
  std::scoped_lock<std::mutex> lock(latch_);
  BUSTUB_ASSERT(frame_id >= 0 && static_cast<size_t>(frame_id) < replacer_size_, "invalid frame_id");

  auto it = node_store_.find(frame_id);
  if (it == node_store_.end()) {
    return;  // 不存在则直接返回
  }
  BUSTUB_ASSERT(it->second.is_evictable_, "Remove on non-evictable frame");
  node_store_.erase(it);
  curr_size_--;
}

auto LRUKReplacer::Size() -> size_t {
  std::scoped_lock<std::mutex> lock(latch_);
  return curr_size_;
}

}  // namespace bustub
